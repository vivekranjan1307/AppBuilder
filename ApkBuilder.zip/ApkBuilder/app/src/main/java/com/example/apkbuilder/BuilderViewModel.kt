package com.example.apkbuilder

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

const val WORKFLOW_FILE = "build.yml"
const val WORKFLOW_PATH = ".github/workflows/$WORKFLOW_FILE"

val WORKFLOW = """
name: Build APKs
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: for z in *.zip; do unzip -q -o "${'$'}z"; done
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: gradle/actions/setup-gradle@v4
        with: { gradle-version: "8.7" }
      - run: |
          for d in */; do
            if [ -f "${'$'}d/settings.gradle.kts" ]; then (cd "${'$'}d" && gradle assembleDebug); fi
          done
      - uses: actions/upload-artifact@v4
        with:
          name: apks
          path: "*/app/build/outputs/apk/debug/*.apk"
""".trimStart()

class BuilderViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var owner by mutableStateOf(prefs.getString("owner", "") ?: "")
    var repo by mutableStateOf(prefs.getString("repo", "") ?: "")
    var branch by mutableStateOf(prefs.getString("branch", "") ?: "")
    var token by mutableStateOf(prefs.getString("token", "") ?: "")

    var fileUri by mutableStateOf<Uri?>(null)
        private set
    var fileName by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    var runUrl by mutableStateOf<String?>(null)
        private set
    val log = mutableStateListOf<String>()
    val apks = mutableStateListOf<File>()

    fun hasSettings() = owner.isNotBlank() && repo.isNotBlank() && token.isNotBlank()

    fun saveSettings() {
        owner = owner.trim(); repo = repo.trim(); branch = branch.trim(); token = token.trim()
        prefs.edit()
            .putString("owner", owner).putString("repo", repo)
            .putString("branch", branch).putString("token", token)
            .apply()
    }

    fun setFile(uri: Uri, name: String) {
        fileUri = uri
        fileName = name
    }

    private fun gh() = GitHub(token, owner, repo)

    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }

    private fun job(block: suspend (GitHub) -> Unit) {
        if (busy || !hasSettings()) return
        busy = true
        log.clear(); apks.clear(); runUrl = null
        viewModelScope.launch {
            try {
                val gh = gh()
                if (branch.isBlank()) {
                    branch = io { gh.defaultBranch() }
                    saveSettings()
                }
                block(gh)
            } catch (e: Exception) {
                log.add("Error: ${e.message ?: e.toString()}")
            } finally {
                busy = false
            }
        }
    }

    private suspend fun ensureWorkflow(gh: GitHub) {
        val existing = io { gh.getFile(WORKFLOW_PATH, branch) }
        val current = existing?.second?.toString(Charsets.UTF_8)?.trim()
        if (current != WORKFLOW.trim()) {
            log.add(if (existing == null) "Adding the build workflow to the repo…" else "Updating the build workflow…")
            io { gh.putFile(WORKFLOW_PATH, WORKFLOW.toByteArray(), "Set up APK build workflow", branch) }
        }
    }

    fun uploadAndBuild() {
        val uri = fileUri ?: return
        val name = fileName
        job { gh ->
            log.add("Checking $owner/$repo…")
            ensureWorkflow(gh)
            val bytes = io { app.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
            log.add("Uploading $name (${bytes.size / 1024} KB)…")
            val sha = io { gh.putFile(name, bytes, "Update $name from APK Builder", branch) }
            log.add("Uploaded. Waiting for the build to start…")
            var run: JSONObject? = null
            for (i in 0 until 24) {
                run = io { gh.runForCommit(sha) }
                if (run != null) break
                delay(5_000)
            }
            if (run == null) {
                log.add("No build started. If the zip didn't change, tap Rebuild instead.")
                return@job
            }
            waitAndFetch(gh, run)
        }
    }

    fun rebuild() {
        job { gh ->
            log.add("Checking $owner/$repo…")
            ensureWorkflow(gh)
            val before = io { gh.latestRunId() }
            io { gh.dispatch(WORKFLOW_FILE, branch) }
            log.add("Build requested. Waiting for it to start…")
            var run: JSONObject? = null
            for (i in 0 until 24) {
                delay(5_000)
                run = io { gh.runNewerThan(before) }
                if (run != null) break
            }
            if (run == null) {
                log.add("The build didn't start. Check the Actions tab on GitHub.")
                return@job
            }
            waitAndFetch(gh, run)
        }
    }

    private suspend fun waitAndFetch(gh: GitHub, first: JSONObject) {
        val id = first.getLong("id")
        runUrl = first.optString("html_url").ifEmpty { null }
        log.add("Build started. This usually takes 3–6 minutes. Keep the app open.")
        val start = System.currentTimeMillis()
        var lastStatus = ""
        while (true) {
            val run = io { gh.getRun(id) }
            val status = run.getString("status")
            if (status != lastStatus) {
                lastStatus = status
                log.add(
                    when (status) {
                        "queued" -> "Waiting in GitHub's queue…"
                        "in_progress" -> "Building…"
                        "completed" -> "Build finished."
                        else -> "Status: $status"
                    }
                )
            }
            if (status == "completed") {
                val conclusion = run.optString("conclusion")
                if (conclusion != "success") {
                    log.add("The build ended with: $conclusion. Open it on GitHub to see the error.")
                    return
                }
                break
            }
            if (System.currentTimeMillis() - start > 30 * 60_000) {
                log.add("Still not done after 30 minutes. Check it on GitHub.")
                return
            }
            delay(10_000)
        }
        val mins = (System.currentTimeMillis() - start) / 60_000
        log.add("Build succeeded${if (mins > 0) " in about $mins min" else ""}. Downloading…")

        val arts = io { gh.artifacts(id) }
        if (arts.length() == 0) {
            log.add("The build didn't produce any files.")
            return
        }
        val dir = File(app.cacheDir, "apks")
        io { dir.deleteRecursively(); dir.mkdirs() }
        for (i in 0 until arts.length()) {
            val artId = arts.getJSONObject(i).getLong("id")
            val zip = File(app.cacheDir, "artifact-$artId.zip")
            io {
                gh.downloadArtifact(artId, zip)
                extractApks(zip, dir)
                zip.delete()
            }
        }
        val found = dir.listFiles { f -> f.extension == "apk" }?.sortedBy { it.name }.orEmpty()
        apks.addAll(found)
        log.add(if (found.isEmpty()) "No APK was found in the download." else "Ready. Tap Install below.")
    }

    private fun extractApks(zip: File, dir: File) {
        ZipInputStream(zip.inputStream()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (!e.isDirectory && e.name.endsWith(".apk")) {
                    val parts = e.name.split("/")
                    val label = if (parts.size > 1) parts.first() + "-" + parts.last() else parts.last()
                    val safe = label.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    File(dir, safe).outputStream().use { zis.copyTo(it) }
                }
            }
        }
    }
}
