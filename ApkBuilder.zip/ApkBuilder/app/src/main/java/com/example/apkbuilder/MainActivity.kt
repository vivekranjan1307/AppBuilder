package com.example.apkbuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val vm: BuilderViewModel = viewModel()
                    LaunchedEffect(vm.busy) {
                        if (vm.busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    BuilderScreen(vm)
                }
            }
        }
    }
}

@Composable
fun BuilderScreen(vm: BuilderViewModel) {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf(!vm.hasSettings()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setFile(uri, displayName(ctx, uri))
    }

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("APK Builder", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("GitHub repo", style = MaterialTheme.typography.titleMedium)
                if (editing) {
                    OutlinedTextField(vm.owner, { vm.owner = it }, label = { Text("Username") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(vm.repo, { vm.repo = it }, label = { Text("Repository name") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(vm.branch, { vm.branch = it }, label = { Text("Branch (leave empty for default)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(vm.token, { vm.token = it }, label = { Text("Access token") },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth())
                    Text(
                        "Create a fine-grained token on GitHub under Settings → Developer settings → " +
                            "Personal access tokens. Give it access to this repo only, and set Contents, " +
                            "Actions and Workflows to Read and write.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(onClick = { vm.saveSettings(); editing = false }, enabled = vm.hasSettings()) {
                        Text("Save")
                    }
                } else {
                    Text("${vm.owner}/${vm.repo}" + if (vm.branch.isNotBlank()) " on ${vm.branch}" else "")
                    TextButton(onClick = { editing = true }, enabled = !vm.busy) { Text("Edit") }
                }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Project", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (vm.fileName.isEmpty()) "Choose the project zip you want to build." else vm.fileName,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                    enabled = !vm.busy
                ) { Text("Choose zip") }
                Button(
                    onClick = { vm.uploadAndBuild() },
                    enabled = !vm.busy && !editing && vm.fileUri != null,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Upload and build") }
                OutlinedButton(
                    onClick = { vm.rebuild() },
                    enabled = !vm.busy && !editing,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Rebuild what's on GitHub") }
            }
        }

        if (vm.busy || vm.log.isNotEmpty()) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Progress", style = MaterialTheme.typography.titleMedium)
                    if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    vm.log.forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    vm.runUrl?.let { url ->
                        TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }) {
                            Text("Open build on GitHub")
                        }
                    }
                }
            }
        }

        if (vm.apks.isNotEmpty()) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Your APKs", style = MaterialTheme.typography.titleMedium)
                    vm.apks.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(f.name, Modifier.weight(1f))
                            Button(onClick = { install(ctx, f) }) { Text("Install") }
                        }
                    }
                }
            }
        }
    }
}

private fun displayName(ctx: Context, uri: Uri): String {
    var name = "project.zip"
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst() && !c.isNull(0)) name = c.getString(0)
    }
    name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
    return if (name.endsWith(".zip", ignoreCase = true)) name else "$name.zip"
}

private fun install(ctx: Context, f: File) {
    if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
        Toast.makeText(ctx, "Allow APK Builder to install apps, then tap Install again.", Toast.LENGTH_LONG).show()
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
        )
        return
    }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(intent)
}
