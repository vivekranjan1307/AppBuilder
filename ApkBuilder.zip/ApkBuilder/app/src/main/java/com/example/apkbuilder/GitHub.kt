package com.example.apkbuilder

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(val code: Int, message: String) : Exception(message)

/** Minimal GitHub REST client for one repository. Call from a background thread. */
class GitHub(private val token: String, owner: String, repo: String) {
    private val base = "https://api.github.com/repos/$owner/$repo"

    private fun open(url: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        return c
    }

    private fun request(method: String, url: String, body: JSONObject? = null): String {
        val c = open(url, method)
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiException(code, friendly(code, text))
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun friendly(code: Int, text: String): String {
        val msg = try { JSONObject(text).optString("message") } catch (e: Exception) { "" }
        return when (code) {
            401 -> "GitHub rejected the token. Check that it's correct and not expired."
            403 -> "The token doesn't have permission for this ($msg). Set Contents, Actions and Workflows to Read and write."
            404 -> "Not found. Check the username, repo name and that the token has access to this repo."
            else -> "GitHub error $code: $msg"
        }
    }

    private fun encPath(path: String) =
        path.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun defaultBranch(): String = JSONObject(request("GET", base)).getString("default_branch")

    /** Returns (sha, content) or null if the file doesn't exist. */
    fun getFile(path: String, branch: String): Pair<String, ByteArray>? = try {
        val o = JSONObject(request("GET", "$base/contents/${encPath(path)}?ref=${enc(branch)}"))
        val content = o.optString("content")
        o.getString("sha") to (if (content.isEmpty()) ByteArray(0) else Base64.decode(content, Base64.DEFAULT))
    } catch (e: ApiException) {
        if (e.code == 404) null else throw e
    }

    private fun getSha(path: String, branch: String): String? = try {
        JSONObject(request("GET", "$base/contents/${encPath(path)}?ref=${enc(branch)}")).optString("sha").ifEmpty { null }
    } catch (e: ApiException) {
        if (e.code == 404) null else throw e
    }

    /** Creates or replaces a file and returns the new commit SHA. */
    fun putFile(path: String, bytes: ByteArray, message: String, branch: String): String {
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("branch", branch)
        getSha(path, branch)?.let { body.put("sha", it) }
        val res = JSONObject(request("PUT", "$base/contents/${encPath(path)}", body))
        return res.getJSONObject("commit").getString("sha")
    }

    fun latestRunId(): Long {
        val arr = JSONObject(request("GET", "$base/actions/runs?per_page=1")).getJSONArray("workflow_runs")
        return if (arr.length() > 0) arr.getJSONObject(0).getLong("id") else 0L
    }

    fun runForCommit(sha: String): JSONObject? {
        val arr = JSONObject(request("GET", "$base/actions/runs?head_sha=$sha&per_page=5")).getJSONArray("workflow_runs")
        return if (arr.length() > 0) arr.getJSONObject(0) else null
    }

    fun runNewerThan(id: Long): JSONObject? {
        val arr = JSONObject(request("GET", "$base/actions/runs?per_page=5")).getJSONArray("workflow_runs")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (r.getLong("id") > id) return r
        }
        return null
    }

    fun dispatch(workflowFile: String, branch: String) {
        request("POST", "$base/actions/workflows/$workflowFile/dispatches", JSONObject().put("ref", branch))
    }

    fun getRun(id: Long): JSONObject = JSONObject(request("GET", "$base/actions/runs/$id"))

    fun artifacts(runId: Long): JSONArray =
        JSONObject(request("GET", "$base/actions/runs/$runId/artifacts")).getJSONArray("artifacts")

    /** Downloads an artifact zip. GitHub redirects to storage; we follow it without the token. */
    fun downloadArtifact(id: Long, dest: File) {
        val c = open("$base/actions/artifacts/$id/zip", "GET")
        c.instanceFollowRedirects = false
        try {
            val code = c.responseCode
            when {
                code in 300..399 -> {
                    val loc = c.getHeaderField("Location") ?: throw ApiException(code, "Download link missing")
                    val d = URL(loc).openConnection() as HttpURLConnection
                    d.connectTimeout = 20_000
                    d.readTimeout = 120_000
                    try {
                        if (d.responseCode !in 200..299) throw ApiException(d.responseCode, "Download failed (${d.responseCode})")
                        d.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
                    } finally {
                        d.disconnect()
                    }
                }
                code in 200..299 -> c.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
                else -> throw ApiException(code, friendly(code, c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""))
            }
        } finally {
            c.disconnect()
        }
    }
}
