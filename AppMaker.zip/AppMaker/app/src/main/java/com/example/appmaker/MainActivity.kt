package com.example.appmaker

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    private val openSlug = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Notify.channels(this)
        openSlug.value = intent?.getStringExtra("slug")
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(openSlug)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        openSlug.value = intent.getStringExtra("slug")
    }
}

private sealed interface Screen {
    data object Home : Screen
    data object Setup : Screen
    data object New : Screen
    data class Detail(val slug: String) : Screen
}

@Composable
private fun AppRoot(openSlug: MutableState<String?>) {
    val vm: AppViewModel = viewModel()
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(if (vm.settingsComplete()) Screen.Home else Screen.Setup) }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(openSlug.value) {
        openSlug.value?.let {
            screen = Screen.Detail(it)
            openSlug.value = null
        }
    }
    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }

    when (val s = screen) {
        Screen.Home -> HomeScreen(vm, onNew = { screen = Screen.New }, onSettings = { screen = Screen.Setup },
            onOpen = { screen = Screen.Detail(it) })
        Screen.Setup -> SettingsScreen(vm, onDone = { screen = Screen.Home })
        Screen.New -> NewScreen(vm, onBack = { screen = Screen.Home }, onCreated = { screen = Screen.Detail(it) })
        is Screen.Detail -> DetailScreen(vm, s.slug, onBack = { screen = Screen.Home })
    }
}

@Composable
private fun Page(title: String, onBack: (() -> Unit)?, action: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) TextButton(onClick = onBack) { Text("Back") }
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            action()
        }
        content()
    }
}

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun HomeScreen(vm: AppViewModel, onNew: () -> Unit, onSettings: () -> Unit, onOpen: (String) -> Unit) {
    Page("App Maker", onBack = null, action = { TextButton(onClick = onSettings) { Text("Settings") } }) {
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth(), enabled = vm.settingsComplete()) { Text("Make a new app") }
        if (!vm.settingsComplete()) Hint("Add your Claude and GitHub details in Settings first.")
        if (vm.projects.isEmpty()) {
            Hint("Your apps will show up here. Each one keeps building in the background, and you'll get a notification when it's ready.")
        }
        vm.projects.forEach { p ->
            ElevatedCard(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(p.slug) }
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    Text(Stage.label(p.stage), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (p.active) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: AppViewModel, onDone: () -> Unit) {
    Page("Settings", onBack = if (vm.settingsComplete()) onDone else null) {
        Card {
            Text("Claude", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(vm.anthropicKey, { vm.anthropicKey = it }, label = { Text("Anthropic API key") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(vm.model, { vm.model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Hint("Create a key at console.anthropic.com. Each request is billed to your Anthropic account.")
        }
        Card {
            Text("GitHub", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(vm.owner, { vm.owner = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(vm.repo, { vm.repo = it }, label = { Text("Repository name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(vm.branch, { vm.branch = it }, label = { Text("Branch (leave empty for default)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(vm.token, { vm.token = it }, label = { Text("Access token") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            Hint("Use a fine-grained token with access to this repo only, with Contents, Actions and Workflows set to Read and write.")
        }
        Card {
            Text("Automatic fixes", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(vm.maxFixes, { vm.maxFixes = it.filter(Char::isDigit).take(1) },
                label = { Text("Times Claude may fix a failed build (0–5)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        }
        Button(onClick = { vm.saveSettings(); onDone() }, enabled = vm.formComplete(), modifier = Modifier.fillMaxWidth()) {
            Text("Save")
        }
    }
}

@Composable
private fun NewScreen(vm: AppViewModel, onBack: () -> Unit, onCreated: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    Page("New app", onBack = onBack) {
        OutlinedTextField(name, { name = it }, label = { Text("App name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("What should it do, and how should it work?") },
            minLines = 8, modifier = Modifier.fillMaxWidth())
        Hint("Describe the screens, what each button does, what the app should remember, and how it should look. The more specific you are, the closer the first version will be.")
        Button(
            onClick = { onCreated(vm.create(name, description)) },
            enabled = name.isNotBlank() && description.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Make app") }
    }
}

@Composable
private fun DetailScreen(vm: AppViewModel, slug: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = vm.projects.firstOrNull { it.slug == slug }
    var change by rememberSaveable { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    Page(p?.name ?: "App", onBack = onBack) {
        if (p == null) {
            Text("Loading…")
            return@Page
        }
        Card {
            Text(Stage.label(p.stage), style = MaterialTheme.typography.titleMedium)
            if (p.active) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Hint("You can leave the app. You'll get a notification when it's done.")
            }
            if (p.summary.isNotBlank()) Text(p.summary)
            val apk = vm.apk(slug)
            if (p.hasApk && apk.exists()) {
                Button(onClick = { install(ctx, apk) }, modifier = Modifier.fillMaxWidth()) { Text("Install") }
            }
            if (p.active) OutlinedButton(onClick = { vm.stop(slug) }, modifier = Modifier.fillMaxWidth()) { Text("Stop") }
            if (p.stage == Stage.FAILED) Button(onClick = { vm.retry(slug) }, modifier = Modifier.fillMaxWidth()) { Text("Try again") }
            if (p.runUrl.isNotBlank()) {
                TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.runUrl))) }) {
                    Text("Open the build on GitHub")
                }
            }
        }
        Card {
            Text("Ask for changes", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(change, { change = it }, label = { Text("What should change?") },
                minLines = 3, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { vm.requestChange(slug, change); change = "" },
                enabled = !p.active && change.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Send changes") }
            if (p.active) Hint("You can send changes once the current step finishes.")
        }
        Card {
            Text("Activity", style = MaterialTheme.typography.titleMedium)
            p.log.asReversed().forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
        TextButton(onClick = { confirmDelete = true }) { Text("Delete this app") }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this app?") },
            text = { Text("This removes its code and APK from this phone. The copy on GitHub stays.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.delete(slug); onBack() }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

private fun install(ctx: Context, f: File) {
    if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
        Toast.makeText(ctx, "Allow App Maker to install apps, then tap Install again.", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")))
        return
    }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}
