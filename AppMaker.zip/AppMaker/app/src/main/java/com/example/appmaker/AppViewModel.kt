package com.example.appmaker

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val settings = Settings(app)

    var projects by mutableStateOf<List<Project>>(emptyList())
        private set

    var anthropicKey by mutableStateOf(settings.anthropicKey)
    var model by mutableStateOf(settings.model)
    var owner by mutableStateOf(settings.owner)
    var repo by mutableStateOf(settings.repo)
    var branch by mutableStateOf(settings.branch)
    var token by mutableStateOf(settings.token)
    var maxFixes by mutableStateOf(settings.maxFixes.toString())

    init {
        viewModelScope.launch {
            while (true) {
                refresh()
                delay(2_000)
            }
        }
    }

    private suspend fun refresh() {
        projects = withContext(Dispatchers.IO) { store.list() }
    }

    private fun refreshSoon() {
        viewModelScope.launch { refresh() }
    }

    fun settingsComplete() = settings.complete()

    fun formComplete() = anthropicKey.isNotBlank() && owner.isNotBlank() && repo.isNotBlank() && token.isNotBlank()

    fun saveSettings() {
        settings.anthropicKey = anthropicKey.trim()
        settings.model = model.trim().ifEmpty { "claude-sonnet-5-5" }
        settings.owner = owner.trim()
        settings.repo = repo.trim()
        settings.branch = branch.trim()
        settings.token = token.trim()
        settings.maxFixes = maxFixes.toIntOrNull()?.coerceIn(0, 5) ?: 3
        model = settings.model
        maxFixes = settings.maxFixes.toString()
    }

    fun create(name: String, description: String): String {
        val slug = store.uniqueSlug(name.trim())
        val p = Project(slug, name.trim(), description.trim())
        p.addLog("Started.")
        store.save(p)
        Scheduler.start(getApplication(), slug)
        refreshSoon()
        return slug
    }

    fun requestChange(slug: String, text: String) {
        store.update(slug) {
            it.stage = Stage.GENERATE
            it.instruction = text.trim()
            it.fixAttempts = 0
            it.genStarts = 0
            it.addLog("You asked for: ${text.trim()}")
        }
        Scheduler.start(getApplication(), slug)
        refreshSoon()
    }

    fun retry(slug: String) {
        val hasSources = store.readSources(slug).isNotEmpty()
        store.update(slug) {
            it.stage = if (it.instruction.isNotBlank() || !hasSources) Stage.GENERATE else Stage.UPLOAD
            it.fixAttempts = 0
            it.genStarts = 0
            it.addLog("Trying again.")
        }
        Scheduler.start(getApplication(), slug)
        refreshSoon()
    }

    fun stop(slug: String) {
        Scheduler.cancel(getApplication(), slug)
        store.update(slug) {
            it.stage = Stage.FAILED
            it.addLog("Stopped by you.")
        }
        refreshSoon()
    }

    fun delete(slug: String) {
        Scheduler.cancel(getApplication(), slug)
        store.delete(slug)
        refreshSoon()
    }

    fun apk(slug: String): File = store.apkFile(slug)
}
