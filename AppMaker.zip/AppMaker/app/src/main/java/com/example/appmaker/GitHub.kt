package com.example.appmaker

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(val code: Int, message: String) : Exception(message)

/** Minimal GitHub REST client for one repository. Call from a background thread. */
class GitHub(private val token: String, owner: String, repo: String) {
    private val base = "https://api.github.com/repos/$owner/$repo"

    private fun open(url: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        return c
    }

    private fun request(method: String, url: String, body: JSONObject? = null): String {
        val c = open(url, method)
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiException(code, friendly(code, text))
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun friendly(code: Int, text: String): String {
        val msg = try { JSONObject(text).optString("message") } catch (e: Exception) { "" }
        return when (code) {
            401 -> "GitHub rejected the token. Check that it's correct and not expired."
            403 -> "The GitHub token doesn't have permission for this ($msg). Set Contents, Actions and Workflows to Read and write."
            404 -> "GitHub says not found. Check the username, repo name and that the token has access to this repo."
            422 -> "GitHub couldn't process the request: $msg"
            else -> "GitHub error $code: $msg"
        }
    }

    private fun encPath(path: String) =
        path.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun defaultBranch(): String = JSONObject(request("GET", base)).getString("default_branch")

    /** Returns (sha, content) or null if the file doesn't exist. */
    fun getFile(path: String, branch: String): Pair<String, ByteArray>? = try {
        val o = JSONObject(request("GET", "$base/contents/${encPath(path)}?ref=${enc(branch)}"))
        val content = o.optString("content")
        o.getString("sha") to (if (content.isEmpty()) ByteArray(0) else Base64.decode(content, Base64.DEFAULT))
    } catch (e: ApiException) {
        if (e.code == 404) null else throw e
    }

    /** Creates or replaces a file and returns the new commit SHA. */
    fun putFile(path: String, bytes: ByteArray, message: String, branch: String): String {
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("branch", branch)
        getFile(path, branch)?.let { body.put("sha", it.first) }
        val res = JSONObject(request("PUT", "$base/contents/${encPath(path)}", body))
        return res.getJSONObject("commit").getString("sha")
    }

    fun dispatch(workflowFile: String, branch: String, inputs: JSONObject) {
        request(
            "POST", "$base/actions/workflows/$workflowFile/dispatches",
            JSONObject().put("ref", branch).put("inputs", inputs)
        )
    }

    /** Finds the run whose title contains [requestId] (set through the workflow's run-name). */
    fun findRun(workflowFile: String, requestId: String): JSONObject? {
        val arr = JSONObject(request("GET", "$base/actions/workflows/$workflowFile/runs?event=workflow_dispatch&per_page=20"))
            .getJSONArray("workflow_runs")
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (r.optString("display_title").contains(requestId)) return r
        }
        return null
    }

    fun getRun(id: Long): JSONObject = JSONObject(request("GET", "$base/actions/runs/$id"))

    fun artifacts(runId: Long): JSONArray =
        JSONObject(request("GET", "$base/actions/runs/$runId/artifacts")).getJSONArray("artifacts")

    fun downloadArtifact(id: Long): ByteArray = downloadRedirect("$base/actions/artifacts/$id/zip")

    /** Returns the most useful part of the failed job's log, for Claude to fix. */
    fun failureLog(runId: Long): String {
        val jobs = JSONObject(request("GET", "$base/actions/runs/$runId/jobs")).getJSONArray("jobs")
        if (jobs.length() == 0) return "(no log available)"
        var job = jobs.getJSONObject(0)
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i)
            if (j.optString("conclusion") == "failure") { job = j; break }
        }
        val text = downloadRedirect("$base/actions/jobs/${job.getLong("id")}/logs").toString(Charsets.UTF_8)
        return excerpt(text)
    }

    private fun excerpt(log: String): String {
        val lines = log.lines().map { it.replace(Regex("^\\S+Z "), "") }
        val keep = sortedSetOf<Int>()
        lines.forEachIndexed { i, l ->
            if (l.startsWith("e: ") || l.contains("error:", ignoreCase = true) || l.contains("What went wrong") ||
                l.contains("Unresolved reference") || l.contains("AAPT") || l.contains("Execution failed")
            ) {
                for (j in (i - 1)..(i + 4)) if (j in lines.indices) keep.add(j)
            }
        }
        val sb = StringBuilder()
        for (i in keep) {
            sb.append(lines[i]).append('\n')
            if (sb.length > 12_000) break
        }
        return if (sb.isEmpty()) lines.takeLast(150).joinToString("\n") else sb.toString()
    }

    /** GitHub answers some downloads with a redirect to storage; follow it without sending the token. */
    private fun downloadRedirect(url: String): ByteArray {
        val c = open(url, "GET")
        c.instanceFollowRedirects = false
        try {
            val code = c.responseCode
            return when {
                code in 300..399 -> {
                    val loc = c.getHeaderField("Location") ?: throw ApiException(code, "Download link missing")
                    val d = URL(loc).openConnection() as HttpURLConnection
                    d.connectTimeout = 20_000
                    d.readTimeout = 120_000
                    try {
                        if (d.responseCode !in 200..299) throw ApiException(d.responseCode, "Download failed (${d.responseCode})")
                        d.inputStream.use { it.readBytes() }
                    } finally {
                        d.disconnect()
                    }
                }
                code in 200..299 -> c.inputStream.use { it.readBytes() }
                else -> throw ApiException(code, friendly(code, c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""))
            }
        } finally {
            c.disconnect()
        }
    }
}
