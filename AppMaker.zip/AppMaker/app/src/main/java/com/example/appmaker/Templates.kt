package com.example.appmaker

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Templates {
    const val WORKFLOW_FILE = "build-one.yml"
    const val WORKFLOW_PATH = ".github/workflows/$WORKFLOW_FILE"

    fun pkg(slug: String) = "com.generated.$slug"

    // "%%" becomes "$" so GitHub's ${{ }} syntax survives Kotlin string templates.
    val WORKFLOW = """
name: Build one app
run-name: build %%{{ inputs.project }} %%{{ inputs.request }}
on:
  workflow_dispatch:
    inputs:
      project:
        description: Project folder name
        required: true
      request:
        description: Request id
        required: true
permissions:
  contents: write
  actions: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Use a stable signing key so updates install over older versions
        run: |
          mkdir -p ~/.android
          if [ -f keystore/debug.keystore ]; then
            cp keystore/debug.keystore ~/.android/debug.keystore
          else
            keytool -genkeypair -keystore ~/.android/debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
            mkdir -p keystore && cp ~/.android/debug.keystore keystore/
            git config user.name "github-actions"
            git config user.email "github-actions@users.noreply.github.com"
            git add keystore/debug.keystore
            git commit -m "Add stable debug keystore [skip ci]"
            git push || true
          fi
      - run: unzip -q -o "generated/%%{{ inputs.project }}.zip"
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: gradle/actions/setup-gradle@v4
        with: { gradle-version: "8.7" }
      - run: gradle assembleDebug --no-daemon
        working-directory: %%{{ inputs.project }}
      - uses: actions/upload-artifact@v4
        with:
          name: apk
          path: %%{{ inputs.project }}/app/build/outputs/apk/debug/app-debug.apk
""".trimStart().replace("%%", "$")

    fun settings(slug: String) = """
pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "$slug"
include(":app")
""".trimStart()

    val ROOT_BUILD = """
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
""".trimStart()

    val GRADLE_PROPS = """
org.gradle.jvmargs=-Xmx3072m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
""".trimStart()

    val WRAPPER = """
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
""".trimStart()

    fun appBuild(slug: String) = """
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "${pkg(slug)}"
    compileSdk = 34
    defaultConfig {
        applicationId = "${pkg(slug)}"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
}
""".trimStart()

    /** Builds the project zip: our fixed Gradle setup plus Claude's source files. */
    fun zip(slug: String, sources: Map<String, String>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            fun add(path: String, content: String) {
                z.putNextEntry(ZipEntry("$slug/$path"))
                z.write(content.toByteArray())
                z.closeEntry()
            }
            add("settings.gradle.kts", settings(slug))
            add("build.gradle.kts", ROOT_BUILD)
            add("gradle.properties", GRADLE_PROPS)
            add("gradle/wrapper/gradle-wrapper.properties", WRAPPER)
            add("app/build.gradle.kts", appBuild(slug))
            for ((path, content) in sources) add(path, content)
        }
        return bos.toByteArray()
    }
}

object Prompts {
    fun system(slug: String, name: String): String {
        val pkg = Templates.pkg(slug)
        val pkgPath = pkg.replace('.', '/')
        return """
You write complete Android apps that a build server compiles automatically. Nobody fixes anything by hand in between, so the code must compile on the first try.

Fixed build setup (already provided; never write Gradle files): Gradle 8.7, Android Gradle Plugin 8.5.2, Kotlin 2.0.20 with the Compose compiler plugin, Java 17, compileSdk 34, targetSdk 34, minSdk 24, one module ":app".
Package and namespace: $pkg. Put Kotlin files under app/src/main/java/$pkgPath/ and start each with "package $pkg" (or a subpackage).

Libraries available. Nothing else exists, so import only from these, the Android SDK and the Kotlin standard library:
- Jetpack Compose from BOM 2024.09.00: ui, ui-graphics, foundation, material3, material-icons-extended
- androidx.activity:activity-compose 1.9.2
- androidx.core:core-ktx 1.13.1
- androidx.lifecycle: lifecycle-runtime-compose and lifecycle-viewmodel-compose 2.8.5
- androidx.navigation:navigation-compose 2.8.0
- org.jetbrains.kotlinx:kotlinx-coroutines-android 1.8.1
- androidx.datastore:datastore-preferences 1.1.1

Files you write:
- app/src/main/AndroidManifest.xml with no package attribute, android:label="$name", android:theme="@style/AppTheme", a MainActivity that is exported and has the MAIN/LAUNCHER intent filter, and every permission the app uses. Don't set android:icon and don't reference mipmap or bitmap images.
- app/src/main/res/values/themes.xml defining AppTheme with parent android:Theme.Material.NoActionBar. Any other resources must be XML (strings, colors, vector drawables).
- Kotlin source. MainActivity extends androidx.activity.ComponentActivity and calls setContent with a MaterialTheme that follows the system light/dark setting.

Rules so the code compiles:
- Import every class and function you use explicitly.
- Material 3 APIs marked experimental (TopAppBar, CenterAlignedTopAppBar, ModalBottomSheet, DatePicker, TimePicker, SwipeToDismissBox, and similar) need @OptIn(ExperimentalMaterial3Api::class) on the function that uses them.
- Use only APIs that exist in these exact versions. Don't use Material 2 components (androidx.compose.material.*) except the icons in androidx.compose.material.icons.
- Request runtime permissions with rememberLauncherForActivityResult and handle refusal gracefully.
- Save data the user expects to keep (notes, scores, settings) with DataStore or files.
- No features that need API keys or servers. No placeholders, TODOs or stubs: implement everything the user asked for, with a clean, easy Material 3 design.

Output format, strictly. Each file:
=== FILE: app/src/main/<path> ===
<the complete file content, without markdown fences>
=== END FILE ===
To remove a file: === DELETE: app/src/main/<path> ===
Finish with a short plain-language summary for the user:
=== SUMMARY ===
<what the app does, or what you changed>
=== END SUMMARY ===
Write nothing outside these blocks.
""".trimStart()
    }

    fun create(name: String, description: String) =
        "Build this app.\n\nApp name: $name\n\nWhat it should do and how it should work:\n$description\n"

    fun change(sources: Map<String, String>, instruction: String) =
        "Here is the current app:\n\n${format(sources)}\n\nThe user wants these changes:\n$instruction\n\n" +
            "Return only the files you add or change, each one complete, plus DELETE lines for files to remove, then the summary."

    fun fix(sources: Map<String, String>, log: String) =
        "Here is the current app:\n\n${format(sources)}\n\nThe build failed. The relevant part of the build log:\n\n$log\n\n" +
            "Fix every error. Return only the files you change, each one complete, then a one-sentence summary of the fix."

    private fun format(sources: Map<String, String>) =
        sources.entries.joinToString("\n") { (p, c) -> "=== FILE: $p ===\n$c\n=== END FILE ===" }

    class Parsed(val files: Map<String, String>, val deletes: Set<String>, val summary: String)

    fun parse(text: String): Parsed {
        val files = linkedMapOf<String, String>()
        val deletes = mutableSetOf<String>()
        var summary = ""
        val lines = text.lines()
        var i = 0
        while (i < lines.size) {
            val t = lines[i].trim()
            when {
                t.startsWith("=== FILE:") && t.endsWith("===") -> {
                    val path = t.removePrefix("=== FILE:").removeSuffix("===").trim()
                    val body = mutableListOf<String>()
                    i++
                    while (i < lines.size && lines[i].trim() != "=== END FILE ===") {
                        body.add(lines[i]); i++
                    }
                    if (body.isNotEmpty() && body[0].trim().startsWith("```")) body.removeAt(0)
                    if (body.isNotEmpty() && body[body.size - 1].trim() == "```") body.removeAt(body.size - 1)
                    if (validPath(path)) files[path] = body.joinToString("\n").trimEnd() + "\n"
                }
                t.startsWith("=== DELETE:") && t.endsWith("===") -> {
                    val path = t.removePrefix("=== DELETE:").removeSuffix("===").trim()
                    if (validPath(path)) deletes.add(path)
                }
                t == "=== SUMMARY ===" -> {
                    val body = mutableListOf<String>()
                    i++
                    while (i < lines.size && lines[i].trim() != "=== END SUMMARY ===") {
                        body.add(lines[i]); i++
                    }
                    summary = body.joinToString("\n").trim()
                }
            }
            i++
        }
        return Parsed(files, deletes, summary)
    }

    private fun validPath(p: String) = p.startsWith("app/src/main/") && !p.contains("..")
}
