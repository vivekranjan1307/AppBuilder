package com.example.appmaker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Stage {
    const val GENERATE = "generate"
    const val FIX = "fix"
    const val UPLOAD = "upload"
    const val DISPATCH = "dispatch"
    const val WAIT = "wait"
    const val DOWNLOAD = "download"
    const val DONE = "done"
    const val FAILED = "failed"
    val active = setOf(GENERATE, FIX, UPLOAD, DISPATCH, WAIT, DOWNLOAD)

    fun label(s: String) = when (s) {
        GENERATE -> "Claude is writing code"
        FIX -> "Claude is fixing build errors"
        UPLOAD -> "Uploading to GitHub"
        DISPATCH, WAIT -> "Building on GitHub"
        DOWNLOAD -> "Downloading the APK"
        DONE -> "Ready to install"
        FAILED -> "Stopped"
        else -> s
    }
}

class Project(val slug: String, var name: String, var description: String) {
    var stage = Stage.GENERATE
    var instruction = ""
    var fixAttempts = 0
    var genStarts = 0
    var buildLog = ""
    var runId = 0L
    var requestId = ""
    var dispatchedAt = 0L
    var runUrl = ""
    var summary = ""
    var hasApk = false
    var updatedAt = System.currentTimeMillis()
    val log = mutableListOf<String>()

    val active: Boolean get() = stage in Stage.active

    fun addLog(msg: String) {
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        log.add("$t  $msg")
        while (log.size > 80) log.removeAt(0)
    }

    fun toJson(): JSONObject = JSONObject()
        .put("slug", slug).put("name", name).put("description", description)
        .put("stage", stage).put("instruction", instruction)
        .put("fixAttempts", fixAttempts).put("genStarts", genStarts).put("buildLog", buildLog)
        .put("runId", runId).put("requestId", requestId).put("dispatchedAt", dispatchedAt)
        .put("runUrl", runUrl).put("summary", summary).put("hasApk", hasApk)
        .put("updatedAt", updatedAt).put("log", JSONArray(log))

    companion object {
        fun fromJson(o: JSONObject) = Project(o.getString("slug"), o.optString("name"), o.optString("description")).apply {
            stage = o.optString("stage", Stage.GENERATE)
            instruction = o.optString("instruction")
            fixAttempts = o.optInt("fixAttempts")
            genStarts = o.optInt("genStarts")
            buildLog = o.optString("buildLog")
            runId = o.optLong("runId")
            requestId = o.optString("requestId")
            dispatchedAt = o.optLong("dispatchedAt")
            runUrl = o.optString("runUrl")
            summary = o.optString("summary")
            hasApk = o.optBoolean("hasApk")
            updatedAt = o.optLong("updatedAt")
            val arr = o.optJSONArray("log")
            if (arr != null) for (i in 0 until arr.length()) log.add(arr.getString(i))
        }
    }
}

/** Keeps each project's status and source files on the phone. */
class Store(ctx: Context) {
    private val root = File(ctx.filesDir, "projects")

    companion object {
        private val lock = Any()
        private val KEYWORDS = setOf(
            "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if", "in", "interface",
            "is", "null", "object", "package", "return", "super", "this", "throw", "true", "try", "typealias",
            "typeof", "val", "var", "when", "while"
        )
    }

    private fun dir(slug: String) = File(root, slug)
    private fun srcDir(slug: String) = File(dir(slug), "src")
    fun apkFile(slug: String) = File(dir(slug), "$slug.apk")

    fun list(): List<Project> = synchronized(lock) {
        root.listFiles()?.mapNotNull { load(it.name) }?.sortedByDescending { it.updatedAt }.orEmpty()
    }

    fun load(slug: String): Project? = synchronized(lock) {
        val f = File(dir(slug), "meta.json")
        if (!f.exists()) null else try { Project.fromJson(JSONObject(f.readText())) } catch (e: Exception) { null }
    }

    fun save(p: Project) = synchronized(lock) {
        p.updatedAt = System.currentTimeMillis()
        dir(p.slug).mkdirs()
        val tmp = File(dir(p.slug), "meta.json.tmp")
        tmp.writeText(p.toJson().toString())
        tmp.renameTo(File(dir(p.slug), "meta.json"))
    }

    fun update(slug: String, block: (Project) -> Unit): Project? = synchronized(lock) {
        val p = load(slug) ?: return null
        block(p)
        save(p)
        p
    }

    fun readSources(slug: String): Map<String, String> {
        val base = srcDir(slug)
        if (!base.exists()) return emptyMap()
        return base.walkTopDown().filter { it.isFile }
            .associate { it.relativeTo(base).path.replace('\\', '/') to it.readText() }
            .toSortedMap()
    }

    fun applyChanges(slug: String, files: Map<String, String>, deletes: Set<String>) {
        val base = srcDir(slug)
        for (path in deletes) File(base, path).delete()
        for ((path, content) in files) {
            val f = File(base, path)
            f.parentFile?.mkdirs()
            f.writeText(content)
        }
    }

    fun delete(slug: String) = synchronized(lock) { dir(slug).deleteRecursively() }

    fun uniqueSlug(name: String): String {
        var base = name.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }.take(30)
        if (base.isEmpty()) base = "app"
        if (base[0].isDigit() || base in KEYWORDS) base = "app$base"
        var slug = base
        var n = 2
        while (dir(slug).exists()) slug = base + n++
        return slug
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private fun str(k: String, d: String = "") = p.getString(k, d) ?: d
    private fun put(k: String, v: String) = p.edit().putString(k, v).apply()

    var anthropicKey: String
        get() = str("anthropicKey")
        set(v) { put("anthropicKey", v) }
    var model: String
        get() = str("model", "claude-sonnet-5-5")
        set(v) { put("model", v) }
    var owner: String
        get() = str("owner")
        set(v) { put("owner", v) }
    var repo: String
        get() = str("repo")
        set(v) { put("repo", v) }
    var branch: String
        get() = str("branch")
        set(v) { put("branch", v) }
    var token: String
        get() = str("token")
        set(v) { put("token", v) }
    var maxFixes: Int
        get() = p.getInt("maxFixes", 3)
        set(v) { p.edit().putInt("maxFixes", v).apply() }

    fun complete() = anthropicKey.isNotBlank() && owner.isNotBlank() && repo.isNotBlank() && token.isNotBlank()
}
