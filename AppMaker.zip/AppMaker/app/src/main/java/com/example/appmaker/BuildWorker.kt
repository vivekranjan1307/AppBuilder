package com.example.appmaker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * Moves one project through: Claude writes code -> upload zip -> start GitHub build ->
 * wait -> (on failure, Claude fixes it and we go again) -> download APK -> notify.
 * Progress is saved after every step, so the job can stop and resume at any point.
 */
class BuildWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val store = Store(ctx)
    private val settings = Settings(ctx)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val slug = inputData.getString("slug") ?: return@withContext Result.failure()
        try {
            process(slug)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val transient = e is IOException ||
                (e is ApiException && (e.code == 429 || e.code == 529 || e.code >= 500))
            if (transient && runAttemptCount < 6) {
                store.update(slug) { it.addLog("Connection problem, trying again soon: ${e.message}") }
                Result.retry()
            } else {
                val p = store.update(slug) {
                    it.stage = Stage.FAILED
                    it.addLog("Stopped: ${e.message ?: e.toString()}")
                }
                Notify.result(applicationContext, slug, p?.name ?: slug, false, e.message ?: "Something went wrong.")
                Result.failure()
            }
        }
    }

    private suspend fun status(p: Project, text: String) {
        try {
            setForeground(Notify.foregroundInfo(applicationContext, p.slug, p.name, text))
        } catch (e: Exception) {
            // Android doesn't allow a foreground notification right now; keep working without it.
        }
    }

    private fun github(): Pair<GitHub, String> {
        val gh = GitHub(settings.token, settings.owner, settings.repo)
        var branch = settings.branch
        if (branch.isBlank()) {
            branch = gh.defaultBranch()
            settings.branch = branch
        }
        return gh to branch
    }

    private suspend fun process(slug: String): Result {
        val deadline = System.currentTimeMillis() + 8 * 60_000
        while (true) {
            val p = store.load(slug) ?: return Result.failure()
            when (p.stage) {
                Stage.GENERATE, Stage.FIX -> generate(p)
                Stage.UPLOAD -> upload(p)
                Stage.DISPATCH -> dispatch(p)
                Stage.WAIT -> {
                    if (!poll(p)) {
                        if (System.currentTimeMillis() > deadline) {
                            Scheduler.later(applicationContext, slug, 20)
                            return Result.success()
                        }
                        delay(15_000)
                    }
                }
                Stage.DOWNLOAD -> download(p)
                else -> return Result.success()
            }
        }
    }

    private suspend fun generate(p: Project) {
        if (p.genStarts >= 3) {
            throw ApiException(0, "Claude kept getting interrupted. Open the app and tap Try again.")
        }
        store.update(p.slug) { it.genStarts++ }
        val sources = store.readSources(p.slug)
        val isFix = p.stage == Stage.FIX
        val (user, msg) = when {
            isFix -> Prompts.fix(sources, p.buildLog) to "Claude is fixing the build errors (attempt ${p.fixAttempts})…"
            sources.isEmpty() -> Prompts.create(p.name, p.description) to "Claude is writing your app…"
            else -> Prompts.change(sources, p.instruction) to "Claude is making your changes…"
        }
        store.update(p.slug) { it.addLog(msg) }
        status(p, msg)
        val text = Claude(settings.anthropicKey, settings.model).complete(Prompts.system(p.slug, p.name), user)
        val parsed = Prompts.parse(text)
        if (parsed.files.isEmpty() && parsed.deletes.isEmpty()) {
            throw ApiException(0, "Claude didn't return any files. Try describing the app differently.")
        }
        store.applyChanges(p.slug, parsed.files, parsed.deletes)
        store.update(p.slug) {
            it.stage = Stage.UPLOAD
            it.instruction = ""
            it.genStarts = 0
            if (parsed.summary.isNotBlank()) it.summary = parsed.summary
            it.addLog("Claude wrote ${parsed.files.size} file(s).")
        }
    }

    private suspend fun upload(p: Project) {
        status(p, "Uploading to GitHub…")
        val (gh, branch) = github()
        val existing = gh.getFile(Templates.WORKFLOW_PATH, branch)
        if (existing?.second?.toString(Charsets.UTF_8)?.trim() != Templates.WORKFLOW.trim()) {
            gh.putFile(Templates.WORKFLOW_PATH, Templates.WORKFLOW.toByteArray(), "Set up App Maker workflow [skip ci]", branch)
        }
        val zip = Templates.zip(p.slug, store.readSources(p.slug))
        gh.putFile("generated/${p.slug}.zip", zip, "Update ${p.slug} from App Maker [skip ci]", branch)
        store.update(p.slug) {
            it.stage = Stage.DISPATCH
            it.addLog("Uploaded to GitHub.")
        }
    }

    private suspend fun dispatch(p: Project) {
        val (gh, branch) = github()
        val req = UUID.randomUUID().toString().take(8)
        gh.dispatch(Templates.WORKFLOW_FILE, branch, JSONObject().put("project", p.slug).put("request", req))
        store.update(p.slug) {
            it.stage = Stage.WAIT
            it.requestId = req
            it.runId = 0
            it.runUrl = ""
            it.dispatchedAt = System.currentTimeMillis()
            it.addLog("Build started on GitHub. This usually takes 3–6 minutes.")
        }
        status(p, "Building on GitHub…")
    }

    /** Returns true when the stage moved on, false while still waiting. */
    private suspend fun poll(p: Project): Boolean {
        val (gh, _) = github()
        if (p.runId == 0L) {
            val run = gh.findRun(Templates.WORKFLOW_FILE, p.requestId)
            if (run == null) {
                if (System.currentTimeMillis() - p.dispatchedAt > 5 * 60_000) {
                    throw ApiException(0, "GitHub didn't start the build. Check the Actions tab in your repo.")
                }
                return false
            }
            store.update(p.slug) {
                it.runId = run.getLong("id")
                it.runUrl = run.optString("html_url")
            }
            return true
        }
        val run = gh.getRun(p.runId)
        if (run.optString("status") != "completed") return false

        if (run.optString("conclusion") == "success") {
            store.update(p.slug) { it.stage = Stage.DOWNLOAD }
            return true
        }
        if (p.fixAttempts < settings.maxFixes) {
            val log = gh.failureLog(p.runId)
            store.update(p.slug) {
                it.buildLog = log
                it.fixAttempts++
                it.stage = Stage.FIX
                it.addLog("The build failed. Sending the errors to Claude to fix.")
            }
        } else {
            val updated = store.update(p.slug) {
                it.stage = Stage.FAILED
                it.addLog("The build still fails after ${it.fixAttempts} fix attempt(s). Open the build on GitHub or ask for a change.")
            }
            Notify.result(applicationContext, p.slug, p.name, false, "The build failed. Open App Maker to see what happened.")
            updated?.let { status(it, "Build failed") }
        }
        return true
    }

    private suspend fun download(p: Project) {
        status(p, "Downloading the APK…")
        val (gh, _) = github()
        val arts = gh.artifacts(p.runId)
        if (arts.length() == 0) throw ApiException(0, "The build finished but produced no APK.")
        val bytes = gh.downloadArtifact(arts.getJSONObject(0).getLong("id"))
        var saved = false
        ZipInputStream(bytes.inputStream()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (!e.isDirectory && e.name.endsWith(".apk")) {
                    store.apkFile(p.slug).outputStream().use { zis.copyTo(it) }
                    saved = true
                    break
                }
            }
        }
        if (!saved) throw ApiException(0, "No APK was found in the build download.")
        store.update(p.slug) {
            it.stage = Stage.DONE
            it.hasApk = true
            it.addLog("APK ready to install.")
        }
        Notify.result(applicationContext, p.slug, p.name, true, "Tap to open it and install.")
    }
}
