package com.example.appmaker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

object Notify {
    private const val PROGRESS = "progress"
    private const val RESULTS = "results"

    fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(PROGRESS, "Build progress", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(RESULTS, "Finished apps", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun openIntent(ctx: Context, slug: String): PendingIntent = PendingIntent.getActivity(
        ctx, slug.hashCode(),
        Intent(ctx, MainActivity::class.java).putExtra("slug", slug)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun foregroundInfo(ctx: Context, slug: String, title: String, text: String): ForegroundInfo {
        channels(ctx)
        val n = NotificationCompat.Builder(ctx, PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent(ctx, slug))
            .build()
        val id = 1000 + (slug.hashCode() and 0xffff)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(id, n)
    }

    fun result(ctx: Context, slug: String, name: String, ok: Boolean, text: String) {
        channels(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(ctx, RESULTS)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "$name is ready to install" else "$name needs attention")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openIntent(ctx, slug))
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(2000 + (slug.hashCode() and 0xffff), n)
        } catch (e: SecurityException) {
        }
    }
}

object Scheduler {
    private fun name(slug: String) = "build-$slug"

    /** Starts (or restarts) the background job for a project. */
    fun start(ctx: Context, slug: String) = enqueue(ctx, slug, 0, ExistingWorkPolicy.REPLACE)

    /** Called by the worker to check back later without keeping the phone busy. */
    fun later(ctx: Context, slug: String, seconds: Long) = enqueue(ctx, slug, seconds, ExistingWorkPolicy.APPEND_OR_REPLACE)

    fun cancel(ctx: Context, slug: String) {
        WorkManager.getInstance(ctx).cancelUniqueWork(name(slug))
    }

    private fun enqueue(ctx: Context, slug: String, seconds: Long, policy: ExistingWorkPolicy) {
        val req = OneTimeWorkRequestBuilder<BuildWorker>()
            .setInputData(workDataOf("slug" to slug))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setInitialDelay(seconds, TimeUnit.SECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(name(slug), policy, req)
    }
}
