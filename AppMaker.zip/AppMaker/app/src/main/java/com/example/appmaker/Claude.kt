package com.example.appmaker

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Calls the Claude Messages API with streaming, so long answers don't time out. */
class Claude(private val apiKey: String, private val model: String) {

    fun complete(system: String, user: String, maxTokens: Int = 32_000, onProgress: (Int) -> Unit = {}): String {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.connectTimeout = 30_000
        c.readTimeout = 180_000
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("stream", true)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) {
                val t = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                val msg = try { JSONObject(t).getJSONObject("error").getString("message") } catch (e: Exception) { t.take(300) }
                val nice = when (code) {
                    401 -> "Claude rejected the API key. Check it in Settings."
                    else -> "Claude API error $code: $msg"
                }
                throw ApiException(code, nice)
            }
            val sb = StringBuilder()
            var stopReason = ""
            var lastReport = 0
            c.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data.isEmpty()) continue
                    val o = try { JSONObject(data) } catch (e: Exception) { continue }
                    when (o.optString("type")) {
                        "content_block_delta" -> {
                            val d = o.getJSONObject("delta")
                            if (d.optString("type") == "text_delta") {
                                sb.append(d.optString("text"))
                                if (sb.length - lastReport > 4_000) {
                                    lastReport = sb.length
                                    onProgress(sb.length)
                                }
                            }
                        }
                        "message_delta" -> {
                            val r = o.optJSONObject("delta")?.optString("stop_reason") ?: ""
                            if (r.isNotEmpty()) stopReason = r
                        }
                        "error" -> {
                            val m = o.optJSONObject("error")?.optString("message") ?: data
                            throw ApiException(529, "Claude API error: $m")
                        }
                    }
                }
            }
            if (stopReason == "max_tokens") {
                throw ApiException(0, "Claude's answer was cut off because the app is too big. Try a simpler description.")
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }
}
